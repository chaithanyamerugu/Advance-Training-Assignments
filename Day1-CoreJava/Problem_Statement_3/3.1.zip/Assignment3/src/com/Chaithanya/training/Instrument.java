package com.chaithanya.training;

public abstract class Instrument {
	public abstract void play();
}
